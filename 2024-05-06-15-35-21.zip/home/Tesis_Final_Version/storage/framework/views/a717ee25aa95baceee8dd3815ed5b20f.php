<!DOCTYPE html>
<html lang="en" class="hydrated">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="\img\logos\logo_tesis.png" alt="logo">
    <meta name=" viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="../css/admin/admin.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>

    <style>
        body {
            overflow-x: hidden;
        }
    </style>
    <script src="../js/menu.js"></script>

</head>

<body>
    <!-- Barra de navegación en el lado izquierdo -->
    <section class="content-sidebar " _ngcontent-ng-c4160891441>

        <div class="content scroll-small">
            <div class="sidebar">
                <a class="logo_site">
                    <div class="img_logo">
                        <img src="\img\logos\logo_tesis.png" alt="logo">
                    </div>
                    <div class="title-text">
                        <p>Gestion Academica</p>
                    </div>
                </a>
                <div class="links_site">
                    <nav class="nav">
                        <ul class="nav-list">
                            <a class="p-element" href="<?php echo e(route('admin.index')); ?>">
                                <div class="icon-sidebar-item">
                                    <i class="material-icons">assignment</i>
                                </div>
                                <div class="name-sidebar-item">
                                    <li>Panel Administrativo</li>
                                </div>
                            </a>
                            <a href="<?php echo e(route('admin.indexProyectos')); ?>" class="p-element">
                                <div class="icon-sidebar-item">
                                    <i class="material-icons">library_books</i>
                                </div>
                                <div class="name-sidebar-item">
                                    <li>Proyectos</li>
                                </div>
                            </a>

                            <a href="<?php echo e(route('admin.estudiantes')); ?>" class="p-element">
                                <div class="icon-sidebar-item">
                                    <i class="fa-solid fa-users fontawesome"></i>
                                </div>
                                <div class="name-sidebar-item">
                                    <li>Estudiantes</li>
                                </div>
                            </a>


                            <a class="p-element submenu" class="p-element" >
                                <div class="icon-sidebar-item">
                                    <i class="material-icons">business</i>
                                </div>
                                <div class="name-sidebar-item">
                                    <li>Prácticas</li>
                                </div>

                            </a>

                            <div class="item-list" id="sublista">
                                <a class="p-element mb-1" href="<?php echo e(route('admin.agregarEmpresa')); ?>">
                                    <div class="icon-sidebar-item">
                                        <i class="material-icons">add_business</i>
                                    </div>
                                    <div class="name-sidebar-item">
                                        <li>Agregar-Empresa</li>
                                    </div>
                                </a>
                                <a class="p-element" href="<?php echo e(route('admin.aceptarFaseI')); ?>">
                                    <div class="icon-sidebar-item">
                                        <i class="material-icons">check_circle</i>
                                    </div>
                                    <div class="name-sidebar-item">
                                        <li>Aprobar-Practicas</li>
                                    </div>
                                </a>

                            </div>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="content-autors">
                <span class="autors1">
                    <i>Designed by Sebastian Flores & Karen Cueva.</i>
                </span>
            </div>
        </div>
        </div>
    </section>
    <!-- SIDEBAR -->
    <section class="content-navbar dimension-nav">
        <!-- Toggle sidebar -->
        <div class="icon-menu-sidebar" onclick="triggerToggleSidebar()">
            <i class='bx bx-menu-alt-left'
                [ngClass]="{'bx-menu': sidebarHidden,'bx-menu-alt-left': !sidebarHidden}"></i>
        </div>
        <!-- contenido -->

        <main class="navbar">
            <button class="profile-icon dropdown" id="profile-button">

                <div class="name-profile">
                    <span><?php echo Auth::user()->NombreUsuario; ?></span>
                </div>
                <div class="icon-profile">
                    <img src="../img/default/user.svg">
                </div>

            </button>
            <!-- Aquí agregamos el contenedor del menú desplegable -->
            <div class="popup-menu-profile">
                <div class="container">
                    <a href="#" class="change_module">
                        <i class="fa-regular fa-rectangle-vertical-history"></i>
                        <span>Cambiar modulo</span>
                    </a>
                    <a class="logout" href="<?php echo e(route('logout')); ?>">
    <i class="fa-sharp fa-regular fa-arrow-up-left-from-circle fontawesome"></i>
    <span>Cerrar sesión</span>
</a>

                </div>
            </div>
        </main>

    </section>
    <button id="btn_top" *ngIf="showScrollButton" (click)="scrollToTop()"><i class='bx bxs-chevrons-up'></i></button>
    <!-- CONTENEDOR -->
    <section class="content-views dimension-content">
        <!-- Title component -->
        <div class="title-component">
            <span class="title-content"><?php echo $__env->yieldContent('title_component'); ?></span>
            <div class="divisor-title"></div>
        </div>
        <!-- Contenido principal -->
        <div class="views">
            <!-- Contenido específico de la página -->
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        

        <style>

        </style>


    </section>
    <!-- Scripts de jQuery y Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <!-- Script de Bootstrap 4.5.2 -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Script de Bootstrap 5.3.0 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(asset('js/plantilla/styles.js')); ?>" type="module"></script>
    <script src="<?php echo e(asset('js/plantilla/vendor.js')); ?>" type="module"></script>
    <script src="<?php echo e(asset('js/plantilla/main.js')); ?>" type="module"></script>
    <script src="<?php echo e(asset('js/admin/general.js')); ?>"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<!-- Box Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    integrity="sha384-gL5q2wHNwpg9voDwmz1onh73oSJ8lFvZEydTHpw4M4okQ7N8qI+v5h0zitOykKdp" crossorigin="anonymous">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</body>

</html>


<?php /**PATH /home/Tesis_Final_Version/resources/views/layouts/admin.blade.php ENDPATH**/ ?>