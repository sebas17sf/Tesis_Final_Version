<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="\img\logos\logo_tesis.png" alt="logo">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="css/login.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
</head>

<body>
    <section class="global_contenedor">
        <div class="main1" id="main1">
            <div class="switch">

                <div class="switch_circle"></div>
                <div class="switch_circle switch_circle_t"></div>
                <div class="switch_circle switch_circle_t2"></div>
                <div class="switch_circle switch_circle_t3"></div>

                <!-- Boton registrarse -->
                <div class="button_container_register">
                    <a href="<?php echo e(route('register')); ?>" class="boton_registro button1" type="button">Regístrate <i class="fa-regular fa-angles-right"></i></a>
                </div>

                <?php if(session('success')): ?>
                        <script>
                            Swal.fire({
                                icon: 'success',
                                title: 'Éxito',
                                text: '<?php echo e(session('success')); ?>',
                                confirmButtonText: 'Ok'
                            });
                        </script>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <script>
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: '<?php echo e(session('error')); ?>',
                                confirmButtonText: 'Ok'
                            });
                        </script>
                    <?php endif; ?>


                <form class="switch_container" action="<?php echo e(route('login')); ?>" method="POST">

                    <img class="logo_login" src="\img\logos\logo_tesis.png" alt="Logo">
                    <h3 class="title" id="sesionTitulo">INICIAR SESIÓN</h3>


                    <?php echo csrf_field(); ?>
                    <!-- Campo de correo electrónico -->
                    <label class="description" for="CorreoElectronico">Correo Electrónico</label>
                    <input class="input form_input" type="email" id="CorreoElectronico" name="CorreoElectronico" required placeholder="Ingrese su correo eléctronico">

                    <!-- Campo de contraseña -->
                    <label class="description" for="Contrasena">Contraseña</label>
                    <input class="input form_input" type="password" id="Contrasena" name="Contrasena" placeholder="Ingrese su contraseña" required>

                    <!-- Olvido la contraseña -->
                    <div class="olvidar_contraseña">
                        <a href="<?php echo e(route('recuperar-contrasena')); ?>">¿Olvidaste tu contraseña?</a>
                    </div>

                    <!-- Botón de enviar -->
                    <div class="btn_contenedor_login">
                        <button type="submit" class="button">Iniciar Sesión</button>
                    </div>

                    <!-- Divisor de botones -->
                    <div class="contenedor_divisor">
                        <hr>
                        <span>o</span>
                        <hr>
                    </div>

                    <!-- Boton de google -->
                    <a href="#" class="btn_google">
                        <img src="\img\logos\google.png" alt="Google Icon" width="20">
                        <span>Continuar con Google</span>
                    </a>

                </form>

            </div>
        </div>
    </section>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.js"></script>
    <script>
        let clickCount = 0;

        function handleClick() {
            clickCount++;
            if (clickCount === 4) {
                Swal.fire({
                    icon: 'info',
                    title: 'Mensaje especial',
                    html: '<div>El creador de esta Tesis: Sebastian Flores es Team GODZILLA</div><img src="https://media.tenor.com/amLCd4kVrX4AAAAi/team-godzilla.gif" alt="Godzilla" style="width: 200px; height: 200px;">',
                    imageWidth: 200,
                    imageHeight: 200
                });
                clickCount = 0;
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const sessionTitle = document.getElementById('sesionTitulo');
            sessionTitle.addEventListener('click', handleClick);
        });
    </script>


</body>

</html>
<?php /**PATH /home/Tesis_Final_Version/resources/views/login.blade.php ENDPATH**/ ?>