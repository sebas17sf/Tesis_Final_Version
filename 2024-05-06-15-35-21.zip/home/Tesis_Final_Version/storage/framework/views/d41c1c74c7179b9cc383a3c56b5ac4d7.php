<?php $__env->startSection('title_component', 'Fase I'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Éxito',
                text: '<?php echo e(session('success')); ?>',
                confirmButtonText: 'Ok'
            });
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?php echo e(session('error')); ?>',
                confirmButtonText: 'Ok'
            });
        </script>
    <?php endif; ?>




    <div class="container" style="overflow-x: auto;">
        <h6><b>Estudiantes a realizar Prácticas</b></h6>
        <hr>
        <?php echo csrf_field(); ?>
        <table class="table table-bordered">
    <thead>
        <tr>
            <th>Estudiante</th>
            <th>Práctica</th>
            <th>Tutor Académico</th>
            <th>Tutor Empresarial</th>
            <th>Empresa</th>
            <th>NRC</th>
            <th>Periodo</th>
             <th>Fecha Inicio</th>
            <th>Fecha Fin</th>
            <th>Horas planificadas</th>
            <th>Estado</th>
            <th>Acción</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $estudiantesConPracticaI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practicaI): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($practicaI->estudiante): ?>
                <tr>
                    <td><?php echo e(strtoupper($practicaI->estudiante->Apellidos)); ?> <?php echo e(strtoupper($practicaI->estudiante->Nombres)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->tipoPractica)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->tutorAcademico->Apellidos)); ?> <?php echo e(strtoupper($practicaI->tutorAcademico->Nombres)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->NombreTutorEmpresarial)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->Empresa->nombreEmpresa)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->nrcPractica->nrc)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->nrcPractica->periodo->numeroPeriodo)); ?></td>
                     <td><?php echo e(strtoupper($practicaI->FechaInicio)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->FechaFinalizacion)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->HorasPlanificadas)); ?></td>
                    <td><?php echo e($practicaI->Estado); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.actualizarEstadoEstudiante', ['id' => $practicaI->estudiante->EstudianteID])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="nuevoEstado">
                                <option value="En ejecucion">Aprobado</option>
                                <option value="Negado">Negar</option>
                            </select>
                            <button type="submit">Enviar</button>
                        </form>

                        <form action="<?php echo e(route('admin.editarNombreEmpresa', ['id' => $practicaI->estudiante->EstudianteID])); ?>" method="GET">
                            <button type="submit">Cambiar Empresa</button>
                        </form>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $estudiantesConPracticaII; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practicaII): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($practicaII->estudiante): ?>
                <tr>
                    <td><?php echo e(strtoupper($practicaII->estudiante->Apellidos)); ?> <?php echo e(strtoupper($practicaII->estudiante->Nombres)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->Practicas)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->DocenteTutor)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->NombreTutorEmpresarial)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->Empresa)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->Nivel)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->FechaInicio)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->FechaFinalizacion)); ?></td>
                    <td><?php echo e(strtoupper($practicaII->HorasPlanificadas)); ?></td>
                    <td><?php echo e($practicaII->Estado); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.actualizarEstadoEstudiante2', ['id' => $practicaII->estudiante->EstudianteID])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="nuevoEstado">
                                <option value="En ejecucion">Aprobado</option>
                                <option value="Negado">Negar</option>
                            </select>
                            <button type="submit">Enviar</button>
                        </form>

                        <form action="<?php echo e(route('admin.editarNombreEmpresa', ['id' => $practicaII->estudiante->EstudianteID])); ?>" method="get">
                            <button type="submit">Cambiar</button>
                        </form>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

    </div>


    <hr>

    <div class="container" style="overflow-x: auto;">
        <h6><b>Estudiantes Practica I</b></h6>
        <hr>
        <?php echo csrf_field(); ?>
        <table class="table table-bordered">
    <thead>
        <tr>
            <th>Estudiante</th>
            <th>Práctica</th>
            <th>Tutor Académico</th>
            <th>Tutor Empresarial</th>
            <th>Empresa</th>
            <th>NRC</th>
            <th>Periodo</th>
            <th>Fecha Inicio</th>
            <th>Fecha Fin</th>
            <th>Horas planificadas</th>
            <th>Estado</th>
            <th>Acción</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $estudiantesPracticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practicaI): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($practicaI->estudiante): ?>
                <tr>
                    <td><?php echo e(strtoupper($practicaI->estudiante->Apellidos)); ?> <?php echo e(strtoupper($practicaI->estudiante->Nombres)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->tipoPractica)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->tutorAcademico->Apellidos)); ?> <?php echo e(strtoupper($practicaI->tutorAcademico->Nombres)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->NombreTutorEmpresarial)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->Empresa->nombreEmpresa)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->nrcPractica->nrc)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->nrcPractica->periodo->numeroPeriodo)); ?></td>

                     <td><?php echo e(strtoupper($practicaI->FechaInicio)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->FechaFinalizacion)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->HorasPlanificadas)); ?></td>
                    <td><?php echo e($practicaI->Estado); ?></td>
                    <td>
                        <form
                            action="<?php echo e(route('admin.actualizarEstadoEstudiante', ['id' => $practicaI->estudiante->EstudianteID])); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="nuevoEstado">
                                <option value="Terminado">Terminado</option>
                                <option value="En ejecucion">Ejecucion</option>
                            </select>
                            <button type="submit">Actualizar</button>
                        </form>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<form method="POST" action="<?php echo e(route('coordinador.reportesPracticaI')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-sm btn-secondary">
            <i class="fas fa-file-excel"></i> Generar Reporte
        </button>
    </form>

    </div>

    <div class="container" style="overflow-x: auto;">
        <h6><b>Estudiantes Practica II<b></h6>
        <hr>
        <?php echo csrf_field(); ?>
        <table class="table table-bordered">
    <thead>
        <tr>
            <th>Estudiante</th>
            <th>Práctica</th>
            <th>Tutor Académico</th>
            <th>Tutor Empresarial</th>
            <th>Empresa</th>
            <th>Nivel</th>
            <th>Fecha Inicio</th>
            <th>Fecha Fin</th>
            <th>Horas planificadas</th>
            <th>Estado</th>
            <th>Acción</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $estudiantesPracticasII; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practicaI): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($practicaI->estudiante): ?>
                <tr>
                    <td><?php echo e(strtoupper($practicaI->estudiante->Apellidos)); ?> <?php echo e(strtoupper($practicaI->estudiante->Nombres)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->Practicas)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->DocenteTutor)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->NombreTutorEmpresarial)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->Empresa)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->Nivel)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->FechaInicio)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->FechaFinalizacion)); ?></td>
                    <td><?php echo e(strtoupper($practicaI->HorasPlanificadas)); ?></td>
                    <td><?php echo e($practicaI->Estado); ?></td>
                    <td>
                        <form
                            action="<?php echo e(route('admin.actualizarEstadoEstudiante2', ['id' => $practicaI->estudiante->EstudianteID])); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="nuevoEstado">
                                <option value="Terminado">Terminado</option>
                                <option value="En ejecucion">Ejecucion</option>
                            </select>
                            <button type="submit">Actualizar</button>
                        </form>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<form method="POST" action="<?php echo e(route('coordinador.reportesPracticaII')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-sm btn-secondary">
            <i class="fas fa-file-excel"></i> Generar Reporte
        </button>
    </form>

    </div>


<?php $__env->stopSection(); ?>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
        white-space: nowrap;
    }

    table,
    th,
    td {
        font-size: 0.8rem;
    }

    th,
    td {
        padding: 8px 12px;
        text-align: left;
        border: 1px solid #ddd;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    th {
        background-color: #f2f2f2;
    }
</style>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/Tesis_Final_Version/resources/views/admin/aceptarFaseI.blade.php ENDPATH**/ ?>